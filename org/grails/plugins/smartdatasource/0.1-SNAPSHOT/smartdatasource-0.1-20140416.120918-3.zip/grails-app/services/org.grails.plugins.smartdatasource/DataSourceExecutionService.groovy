package org.grails.plugins.smartdatasource
/**
 * Created by dhalupa on 4/15/14.
 */
class DataSourceExecutionService {


    def grailsApplication
    def messageSource

    def executeTransaction(transaction) {
        def model = []
        transaction.operations.each { request ->
            def resp = executeOperation(request)
            resp.response.queueStatus = 0
            model << resp
        }
        model
    }

    def executeOperation(request) {
        def dataSource = resolveDataSource(request.dataSource)
        def handler = this[request.operationType]
        def retValue
        try {
            retValue = handler.call(dataSource, request)
        } catch (Throwable t) {
            log.error(t.message, t)
            retValue = ['response': [status: -1, data: t.message]]
        }
        retValue
    }

    private def resolveDataSource(name) {
        def dataSourceClass = grailsApplication.getArtefactByLogicalPropertyName(DataSourceArtefactHandler.TYPE, name)
        def dataSource = grailsApplication.mainContext.getBean("${dataSourceClass.fullName}")
        dataSource
    }


    private fetch = { dataSource, request ->
        def model = dataSource.fetch(request.data)
        return ['response': [
                status: 0,
                startRow: 0,
                endRow: model.size(),
                totalRows: model.size(),
                data: model
        ]
        ]
    }


    private handler = { dataSource, request ->
        def value = dataSource.invokeMethod(request.operationType, [request.data] as Object[])
        return renderDataUpdateResponse(value)
    }

    private update = { dataSource, request -> handler.call(dataSource, request) }
    private add = { dataSource, request -> handler.call(dataSource, request) }
    private remove = { dataSource, request -> handler.call(dataSource, request) }

    private custom = { dataSource, request ->
        def value = dataSource.invokeMethod(request.operationId, [request.data] as Object[])
        return renderDataUpdateResponse([retValue: value])
    }


    private def renderDataUpdateResponse(value) {
        if (value.errors?.hasErrors()) {
            def d = ['response': [status: -4]]
            def errors = [:]
            value.errors.allErrors.each { err ->
                if (!errors[err.field]) {
                    errors[err.field] = [
                            [errorMessage: messageSource.getMessage(err, null)]
                    ]
                } else {
                    errors[err.field] << [errorMessage: messageSource.getMessage(err, null)]
                }
            }
            d.response.errors = errors
            return d
        } else {
            return renderDataResponse(value)
        }
    }


    private def renderDataResponse(value) {
        return ['response': [status: 0, data: value]]
    }


}
