package org.grails.plugins.smartdatasource

import org.grails.plugins.smartdatasource.builder.FieldsDefinitionBuilder
import org.springframework.transaction.support.TransactionCallback
import org.springframework.transaction.support.TransactionTemplate

import java.text.DateFormat;
import java.text.SimpleDateFormat

import org.codehaus.groovy.grails.commons.GrailsClassUtils;
import org.codehaus.groovy.grails.web.converters.configuration.ConverterConfiguration;
import org.codehaus.groovy.grails.web.converters.configuration.ConvertersConfigurationHolder
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import grails.converters.JSON

/**
 * Controller responsible for json communication SmartClient datasource instance
 *
 * @author Denis Halupa
 */
class DatasourceController {

    def messageSource
    def grailsApplication

    def dataSourceDefinitionService
    def dataSourceExecutionService


    def index = { serve() }


    def serve() {
        def model
        if (request.JSON.transaction) {
            model = dataSourceExecutionService.executeTransaction(request.JSON.transaction)
        } else {
            model = dataSourceExecutionService.executeOperation(request.JSON)
        }
        JSON.use('smart', {
            render dataSourceDefinitionService.jsonPrefix + (model as JSON) + dataSourceDefinitionService.jsonSuffix
        })

    }


    def definitions() {
        render(text: dataSourceDefinitionService.getDefinitions(params.lang), contentType: 'application/javascript')
    }


}
