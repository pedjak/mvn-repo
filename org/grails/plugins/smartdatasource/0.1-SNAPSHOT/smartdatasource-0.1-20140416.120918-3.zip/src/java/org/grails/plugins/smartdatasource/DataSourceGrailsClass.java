package org.grails.plugins.smartdatasource;

import org.codehaus.groovy.grails.commons.InjectableGrailsClass;

public interface DataSourceGrailsClass extends  InjectableGrailsClass{

}
