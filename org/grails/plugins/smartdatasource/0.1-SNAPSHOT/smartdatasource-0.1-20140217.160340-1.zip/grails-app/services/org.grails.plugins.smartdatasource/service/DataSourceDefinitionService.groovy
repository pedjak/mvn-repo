package org.grails.plugins.smartdatasource.service

import grails.converters.JSON
import org.codehaus.groovy.grails.commons.DomainClassArtefactHandler
import org.codehaus.groovy.grails.commons.GrailsDomainClass
import org.codehaus.groovy.grails.commons.GrailsDomainClassProperty
import org.grails.plugins.smartdatasource.DatasourceController
import org.grails.plugins.smartdatasource.annotation.Progress
import org.grails.plugins.smartdatasource.builder.FieldsDefinitionBuilder
import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU
import org.springframework.context.MessageSource
import org.springframework.context.NoSuchMessageException

import java.beans.Introspector

class DataSourceDefinitionService {

    static jsonPrefixString = "<SCRIPT>//'\"]]>>isc_JSONResponseStart>>"
    static jsonSuffixString = "//isc_JSONResponseEnd"


    private Map cachedDefinitions = [:]

    static transactional = false

    def grailsApplication
    def messageSource

    static def SYSTEM_PROPS = ['version', 'created']

    static
    def TYPE_MAPPING = ['string': 'text', 'long': 'integer', 'boolean': 'boolean', 'integer': 'integer', 'date': 'date', 'float': 'float', 'double': 'float']

    def resetDefinitions() {
        cachedDefinitions = [:]
    }

    def getDefinitions(lang) {
        if (!cachedDefinitions[lang]) {
            def d = grailsApplication.dataSourceClasses.findAll { ds -> ds.name }.collect { dataSourceClass ->
                buildDataSourceDefinition(dataSourceClass, lang)
            }
            StringBuilder b = new StringBuilder()
            d.each {
                String c = new JSON(it as Map).toString()
                b.append("isc.RestDataSource.create(${c});")
            }
            cachedDefinitions[lang] = b.toString()
        }
        cachedDefinitions[lang]

    }

    def getJsonPrefix() {
        return grailsApplication.config.grails.plugin.smartdatasource.debug ? '' : jsonPrefixString
    }

    def getJsonSuffix() {
        return grailsApplication.config.grails.plugin.smartdatasource.debug ? '' : jsonSuffixString
    }

    private def buildDataSourceDefinition = { dsClass, lang ->
        def ds = [dataURL: 'datasource', ID: dsClass.logicalPropertyName, dataFormat: 'json']
        def dsConfig = GCU.getStaticPropertyValue(dsClass.getClazz(), 'config')
        if (dsConfig) ds << dsConfig
        ds.fields = buildFieldsDefinition(dsClass)
        ds.progressInfo = buildProgressInfo(dsClass.getClazz(), lang, ds.ID)
        ds.operationBindings = buildOperationsDefinition(dsClass, ds)
        ds.jsonPrefix = this.jsonPrefix
        ds.jsonSufix = this.jsonSuffix
        ds
    }

    private def buildProgressInfo = { Class clazz, String lang, String dsID ->
        Locale locale = new Locale(lang)
        def args = new Object[0]
        clazz.declaredMethods.findAll { it.getAnnotation(Progress.class) } collectEntries {
            Progress ann = it.getAnnotation(Progress.class)
            String key = "${dsID}.${it.name}"
            [(key): messageSource.getMessage(ann.value(), args, locale)]
        }
    }

    private def buildOperationsDefinition = { dataSourceClass, ds ->
        def operations = GCU.getStaticPropertyValue(dataSourceClass.getClazz(), 'operations')
        operations.collect {
            def op = [operationType: it, dataProtocol: "postMessage"]
            String key = "${ds.ID}.${it}"
            if (ds.progressInfo[key]) {
                op.requestProperties = [prompt: ds.progressInfo.remove(key)]
            }
            op
        }
    }


    private def buildFieldsDefinition = { dsClass ->
        def fd = [:]
        Class clazz = dsClass.getClazz()
        def included = GCU.getStaticPropertyValue(clazz, 'included') ?: []
        def excluded = GCU.getStaticPropertyValue(clazz, 'excluded') ?: []
        GrailsDomainClass domainClass = resolveDomainClass(dsClass)
        if (domainClass) {
            GrailsDomainClassProperty id = domainClass.getIdentifier();
            buildFieldDefinition(id, fd)
            if (included) {
                included.each { i ->
                    GrailsDomainClassProperty p = domainClass.getPropertyByName(i)
                    if (p) {
                        buildFieldDefinition(p, fd)
                    } else {
                        throw new RuntimeException("Included property '${i}' can not be found")
                    }
                }
            } else {
                domainClass.properties.each { GrailsDomainClassProperty p ->
                    if (!p.identity && !excluded.contains(p.name)) {
                        buildFieldDefinition(p, fd)
                    }
                }

            }
        }
        applyFieldsDefinition(dsClass, fd)
        fd
    }

    private def buildFieldDefinition = { GrailsDomainClassProperty prop, Map fieldsDefinition ->
        if (prop.persistent && !prop.association && prop.typePropertyName != 'object') {
            if (!SYSTEM_PROPS.contains(prop.name)) {
                def defn = [name: prop.name]
                if (prop.identity) {
                    defn << [hidden: true, primaryKey: true]
                } else {
                    def title = resolveTitle(prop)
                    if (title) {
                        defn.title = title
                    }
                }
                defn.type = resolveType(prop)
                fieldsDefinition[prop.name] = defn
            }
        }
    }

    private def resolveTitle = { prop ->
        try {
            return messageSource.getMessage("smart.field.${prop.domainClass.logicalPropertyName}.${prop.name}.title".toString(), [] as Object[], null)
        } catch (NoSuchMessageException e) {
            return null
        }
    }

    private def resolveDomainClass = { dsClass ->
        Class clazz = dsClass.getClazz()
        String domainClassName = GCU.getStaticPropertyValue(clazz, 'domainClass')?.simpleName ?: dsClass.logicalPropertyName
        GrailsDomainClass domainClass = grailsApplication.getArtefactByLogicalPropertyName(DomainClassArtefactHandler.TYPE, Introspector.decapitalize(domainClassName));
        if (domainClass) {
            return domainClass
        } else {
            //  throw new RuntimeException('Domain class could not be resolved')
            return null
        }

    }

    private def applyFieldsDefinition = { dsClass, Map fieldsDefinition ->
        def meta = GCU.getStaticPropertyValue(dsClass.clazz, 'fields')
        if (meta) {
            FieldsDefinitionBuilder builder = new FieldsDefinitionBuilder()
            meta.delegate = builder
            meta.resolveStrategy = Closure.DELEGATE_FIRST
            meta()
            builder.config.each { key, value ->
                if (fieldsDefinition[key]) {
                    fieldsDefinition[key] << value
                } else {
                    fieldsDefinition[key] = value
                }
            }
        }
    }

    private def resolveType = { GrailsDomainClassProperty prop ->
        def type = TYPE_MAPPING[prop.typePropertyName]
        if (type) {
            return type
        } else {
            return 'any'
        }

    }


}
